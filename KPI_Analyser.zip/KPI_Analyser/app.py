from flask import Flask, request, render_template, send_from_directory, jsonify
import os
from werkzeug.utils import secure_filename
from kpi_detector import KPIAnomalyDetector  # Importing the KPI detection logic

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
REPORT_FOLDER = 'reports'
ALLOWED_EXTENSIONS = {'xlsx'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['REPORT_FOLDER'] = REPORT_FOLDER

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    # List reports by date
    reports = sorted(os.listdir(app.config['REPORT_FOLDER']), reverse=True)
    return render_template('index.html', reports=reports)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        # Run KPI anomaly detection
        detector = KPIAnomalyDetector(file_path)
        detector.run(generate_html=True)

        # Generate report path
        report_name = f"{filename}_report.html"
        report_path = os.path.join(app.config['REPORT_FOLDER'], report_name)

        if os.path.exists(report_path):
            return jsonify({"message": "File processed successfully!", "report_url": f"/reports/{report_name}"}), 200
        else:
            return jsonify({"error": "Report generation failed"}), 500

    return jsonify({"error": "Invalid file type"}), 400

@app.route('/reports/<filename>')
def get_report(filename):
    return send_from_directory(app.config['REPORT_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)  # Set host to 0.0.0.0 for external access